ad= input("adınızı girin: ")
soyad=input("soyadınzı girin ")

print (ad[0].upper() + "." + soyad[0].upper())