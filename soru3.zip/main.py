kelime= input("Bir kelime girin: ")
print(kelime[0]+kelime[-1])